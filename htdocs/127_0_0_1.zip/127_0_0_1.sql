-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 08-03-2022 a las 17:41:16
-- Versión del servidor: 5.7.36
-- Versión de PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `mante`
--
CREATE DATABASE IF NOT EXISTS `mante_correctivo` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `mante_correctivo`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

DROP TABLE IF EXISTS `departamento`;
CREATE TABLE IF NOT EXISTS `departamento` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `departamento_nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `departamento`
--

INSERT INTO `departamento` (`id`, `departamento_nombre`) VALUES
(1, 'Cosecha y Campo'),
(2, 'Lavadoras'),
(3, 'Molinos y Envasados'),
(4, 'Mantenimineto Industrial'),
(5, 'Taller Automotriz'),
(6, 'Embarques'),
(7, 'Control de Calidad'),
(8, 'Oficinas'),
(9, 'Climas'),
(10, 'CMMS');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `equipo`
--

DROP TABLE IF EXISTS `equipo`;
CREATE TABLE IF NOT EXISTS `equipo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `equipo_clave` varchar(20) NOT NULL,
  `equipo_nombre` char(60) NOT NULL,
  `equipo_marca` char(30) DEFAULT NULL,
  `equipo_modelo` char(30) DEFAULT NULL,
  `equipo_manual` blob,
  `equipo_serie` varchar(60) DEFAULT NULL,
  `equipo_ano` year(4) DEFAULT NULL,
  `equipo_color` varchar(10) DEFAULT NULL,
  `departamento_id` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `departamento_id` (`departamento_id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `equipo`
--

INSERT INTO `equipo` (`id`, `equipo_clave`, `equipo_nombre`, `equipo_marca`, `equipo_modelo`, `equipo_manual`, `equipo_serie`, `equipo_ano`, `equipo_color`, `departamento_id`) VALUES
(1, '.', 'Bascula 1', 'Chantland', '', '', '', NULL, '', 3),
(2, '.', 'Bascula 2', 'Chantland', '', '', '', NULL, '', 3),
(3, '.', 'Bascula 3', 'Chantland', '', '', '', NULL, '', 3),
(4, '.', 'Bascula 4', 'Chantland', '', '', '', NULL, '', 3),
(5, '.', 'Bascula 5', 'Chantland', '', '', '', NULL, '', 3),
(6, '.', 'Bascula 6', 'Chantland', '', '', '', NULL, '', 3),
(7, '.', 'Bascula 7', 'Chantland', '', '', '', NULL, '', 3),
(8, '.', 'Bascula 8', 'Chantland', '', '', '', NULL, '', 3),
(9, '.', 'Bascula 9', 'Chantland', '', '', '', NULL, '', 3),
(10, '.', 'Banda Alimentación de Cernidas', '', '', '', '', NULL, '', 3),
(11, '.', 'Banda Alimentación de Directas', '', '', '', '', NULL, '', 3),
(12, '.', 'Banda Móvil de Sacos 1,2,3', '', '', '', '', NULL, '', 3),
(13, '.', 'Banda de Sacos Auxiliar 1', '', '', '', '', NULL, '', 3),
(14, '.', 'Banda Telescopica 1', '', '', '', '', NULL, '', 3),
(15, '.', 'Banditas de Sacos 1', '', '', '', '', NULL, '', 3),
(16, '.', 'Banditas de Sacos 2', '', '', '', '', NULL, '', 3),
(17, '.', 'Banditas de Sacos 3', '', '', '', '', NULL, '', 3),
(18, '.', 'Banditas de Sacos 4', '', '', '', '', NULL, '', 3),
(19, '.', 'Banditas de Sacos 5', '', '', '', '', NULL, '', 3),
(20, '.', 'Banditas de Sacos 6', '', '', '', '', NULL, '', 3),
(21, '.', 'Banditas de Sacos 7', '', '', '', '', NULL, '', 3),
(22, '.', 'Banditas de Sacos 8', '', '', '', '', NULL, '', 3),
(23, '.', 'Banditas de Sacos 9', '', '', '', '', NULL, '', 3),
(24, '.', 'Compresor de Directas', 'Ingersoll Rand', 'R37IE-TAS-A118', '', '', NULL, '', 3),
(25, '.', 'Criba Megatex', '', '', '', '', NULL, '', 3),
(26, '.', 'Criba Materia Extraña', '', '', '', '', NULL, '', 3),
(27, '.', 'Criba Apex', 'Apex', '', '', '', NULL, '', 3),
(28, '.', 'Detector de Metales 2 Brapenta', 'Brapenta', 'Insight', '', '', NULL, '', 3),
(29, '.', 'Detector de Metales 3 Minibea', 'Minebea', 'Vistus-C70X35', '', '', NULL, '', 3),
(30, '.', 'Elevador de Cangilones Primario', 'Martin', 'C148 - 779 - S6', '', '', NULL, '', 3),
(31, '.', 'Elevador de Cangilones Secundario', '', '74-7601976', '', '', NULL, '', 3),
(32, '.', 'Extractor de la Secadora', '', '', '', '', NULL, '', 3),
(33, '.', 'Extractor de Polvos', '', '', '', '', NULL, '', 3),
(34, '.', 'Gusano Alimentador del Elevador Secundario', 'Martin', ' 74-7601976.002', '', '', NULL, '', 3),
(35, '.', 'Gusano Alimentación de Molino 1 y 2', 'Martin', '74 - 7740549      TAG  01', '', '', NULL, '', 3),
(36, '.', 'GUSANO DE BIG BAG 1', 'SN', 'SN', '', '', NULL, '', 3),
(37, '.', 'Gusano de Directas 1', '', '', '', '', NULL, '', 3),
(38, '.', 'Gusano de Directas 2', '', '', '', '', NULL, '', 3),
(39, '.', 'Gusano de la Secadora', 'Martin', '18\"', '', '', NULL, '', 3),
(40, '.', 'Gusano de Anisal', '', '', '', '', NULL, '', 3),
(41, '.', 'Gusano de Grano Industrial', 'Martin', '14\"', '', '', NULL, '', 3),
(42, '.', 'Gusano de Martajada', 'Martin', '14\"', '', '', NULL, '', 3),
(43, '.', 'Gusano de Molida', 'Martin', '14\"', '', '', NULL, '', 3),
(44, '.', 'Gusano de Refinada', 'Martin', '14\"', '', '', NULL, '', 3),
(45, '.', 'Transportador de Rastras Martin 1', 'Martin', '14\"', '', '', NULL, '', 3),
(46, '.', 'Transportador de Rastras Martin 2', 'Martin', '1600-RB', '', '', NULL, '', 3),
(47, '.', 'Transportador de Rastras Tramco 1', 'Tramco', '12 RB', '', '', NULL, '', 3),
(48, '.', 'Transportador de Rastras Tramco 2', 'Tramco', '12 RB', '', '', NULL, '', 3),
(49, '.', 'Impulsor de Aire de Combustión (Blower)', '', '', '', '', NULL, '', 3),
(50, '.', 'Maquina de Coser 1', 'Fischbein', '100', '', '', NULL, '', 3),
(51, '.', 'Maquina de Coser 2', 'Fischbein', '100', '', '', NULL, '', 3),
(52, '.', 'Maquina de Coser 3', 'Fischbein', '100', '', '', NULL, '', 3),
(53, '.', 'Maquina de Coser 4', 'Fischbein', '100', '', '', NULL, '', 3),
(54, '.', 'Maquina de Coser 5', 'Fischbein', '100', '', '', NULL, '', 3),
(55, '.', 'Maquina de Coser 6', 'Fischbein', '100', '', '', NULL, '', 3),
(56, '.', 'Maquina de Coser 7', 'Fischbein', '100', '', '', NULL, '', 3),
(57, '.', 'Maquina de Coser 8', 'Fischbein', '100', '', '', NULL, '', 3),
(58, '.', 'Maquina de Coser 9', 'Fischbein', '100', '', '', NULL, '', 3),
(59, '.', 'Maquina Briquetadora Pellets', 'komarek', 'B220B', '', '', NULL, '', 3),
(60, '.', 'Maquina Selladora', '', '', '', '', NULL, '', 3),
(61, '.', 'Molino 1', 'Roskamp', 'SRC1200 - 52', '', '', NULL, '', 3),
(62, '.', 'Molino 2', 'Roskamp', 'SRC1200 - 52', '', '', NULL, '', 3),
(63, '.', 'Quemador del Horno', 'hauck', '1', '', '', NULL, '', 3),
(64, '.', 'Ventilador Secundario del Quemador', 'hauck', '1', '', '', NULL, '', 3),
(65, '.', 'Secadora', '', '', '', '', NULL, '', 3),
(66, '.', 'Tolva de Alimentación Cernidas', '', '', '', '', NULL, '', 3),
(67, '.', 'Tolva de Alimentación Directas', '', '', '', '', NULL, '', 3),
(68, '.', 'Tolva de Directas 1', '', '', '', '', NULL, '', 3),
(69, '.', 'Tolva de Directas 2', '', '', '', '', NULL, '', 3),
(70, '.', 'Tolva de Directas 3', '', '', '', '', NULL, '', 3),
(71, '.', 'Tolva de Anisal', '', '', '', '', NULL, '', 3),
(72, '.', 'Tolva de Grano Industrial', '', '', '', '', NULL, '', 3),
(73, '.', 'Tolva de Martajada', '', '', '', '', NULL, '', 3),
(74, '.', 'Tolva de Molida', '', '', '', '', NULL, '', 3),
(75, '.', 'Tolva de Refinada', '', '', '', '', NULL, '', 3),
(76, '.', 'Tren de Válvulas', '', '', '', '', NULL, '', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

DROP TABLE IF EXISTS `estado`;
CREATE TABLE IF NOT EXISTS `estado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `estado_tipo` char(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `estado`
--

INSERT INTO `estado` (`id`, `estado_tipo`) VALUES
(1, 'ACTIVO'),
(2, 'PENDIENTE'),
(3, 'COMPLETADO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulo`
--

DROP TABLE IF EXISTS `modulo`;
CREATE TABLE IF NOT EXISTS `modulo` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `modulo_nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orden_solicitud`
--

DROP TABLE IF EXISTS `orden_solicitud`;
CREATE TABLE IF NOT EXISTS `orden_solicitud` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `departamento_id` int(2) NOT NULL,
  `orden_descripcion` varchar(250) NOT NULL,
  `orden_paro` char(3) NOT NULL,
  `orden_fecha` date NOT NULL,
  `orden_hora` time NOT NULL,
  `orden_recibe_persona` varchar(100) DEFAULT NULL,
  `equipo_id` int(11) NOT NULL,
  `estado_id` int(11) NOT NULL,
  `persona_id` int(2) NOT NULL,
  `tipo_id` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `equipo_id` (`equipo_id`),
  KEY `estado_id` (`estado_id`),
  KEY `persona_id` (`persona_id`),
  KEY `tipo_id` (`tipo_id`),
  KEY `departamento_id` (`departamento_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orden_trabajo`
--

DROP TABLE IF EXISTS `orden_trabajo`;
CREATE TABLE IF NOT EXISTS `orden_trabajo` (
  `id` int(11) NOT NULL,
  `num_herramienta` int(3) DEFAULT NULL,
  `desripcion_trabajo` varchar(250) NOT NULL,
  `hora_inicio` datetime NOT NULL,
  `hora_fin` datetime NOT NULL,
  `ejecutantes` varchar(250) DEFAULT NULL,
  `refacciones` mediumtext,
  `trabajo_recibe_persona` varchar(100) DEFAULT NULL,
  `orden_id` int(11) NOT NULL,
  `persona_id` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `orden_id` (`orden_id`),
  KEY `persona_id` (`persona_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permisos`
--

DROP TABLE IF EXISTS `permisos`;
CREATE TABLE IF NOT EXISTS `permisos` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `rol_id` int(1) NOT NULL,
  `modulo_id` int(2) NOT NULL,
  `leer` char(2) NOT NULL,
  `escribir` char(2) NOT NULL,
  `actualizar` char(2) NOT NULL,
  `eliminar` char(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rol_id` (`rol_id`),
  KEY `modulo_id` (`modulo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

DROP TABLE IF EXISTS `persona`;
CREATE TABLE IF NOT EXISTS `persona` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `persona_nombres` varchar(30) NOT NULL,
  `persona_AP` varchar(15) NOT NULL,
  `persona_AM` varchar(15) DEFAULT NULL,
  `persona_usuario` char(15) NOT NULL,
  `persona_contrasena` varchar(60) NOT NULL,
  `rol_id` int(1) NOT NULL,
  `departamento_id` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rol_id` (`rol_id`),
  KEY `departamento_id` (`departamento_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`id`, `persona_nombres`, `persona_AP`, `persona_AM`, `persona_usuario`, `persona_contrasena`, `rol_id`, `departamento_id`) VALUES
(1, 'Jeronimo', 'Ramos', '', 'JRAMOS', 'salsol', 1, 10),
(2, 'Luis', 'Ek', '', 'LEK', 'salsol', 1, 10),
(3, 'Roberto', 'Orozco', '', 'ROROZCO', 'salsol', 2, 4),
(4, 'Alberto', 'Zamudio', '', 'AZAMUDIO', 'salsol', 2, 4),
(5, 'Edwin', 'Montero', '', 'EMONTERO', 'salsol', 2, 4),
(6, 'Santos Gerardo', 'Puc', '', 'SPUC', 'salsol', 2, 4),
(7, 'Venancio', 'Puc', '', 'VPUC', 'salsol', 2, 4),
(8, 'Ricardo', 'Castillo', '', 'RCASTILLO', 'salsol', 2, 4),
(9, 'Victor', 'Canto', '', 'VCANTO', 'salsol', 2, 7),
(10, 'Felix', 'Reda', '', 'FREDA', 'salsol', 2, 3),
(11, 'Max', 'Mendez', '', 'MMENDEZ', 'salsol', 2, 3),
(12, 'Antonio', 'Pererra', '', 'APERERA', 'salsol', 2, 3),
(13, 'Frank', 'Cano', '', 'FCANO', 'salsol', 2, 3),
(14, 'Jenifer', 'Basulto', '', 'JBASULTO', 'salsol', 2, 3),
(15, 'Alejandro', 'Nauat', 'Durán', 'ANAUAT', 'salsol', 1, 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

DROP TABLE IF EXISTS `rol`;
CREATE TABLE IF NOT EXISTS `rol` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `rol_nombre` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`id`, `rol_nombre`) VALUES
(1, 'Administrador'),
(2, 'Supervisor');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_orden`
--

DROP TABLE IF EXISTS `tipo_orden`;
CREATE TABLE IF NOT EXISTS `tipo_orden` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tipo_orden`
--

INSERT INTO `tipo_orden` (`id`, `descripcion`) VALUES
(1, 'MCorrectivo');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `equipo`
--
ALTER TABLE `equipo`
  ADD CONSTRAINT `equipo_ibfk_1` FOREIGN KEY (`departamento_id`) REFERENCES `departamento` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `orden_solicitud`
--
ALTER TABLE `orden_solicitud`
  ADD CONSTRAINT `orden_solicitud_ibfk_1` FOREIGN KEY (`equipo_id`) REFERENCES `equipo` (`id`),
  ADD CONSTRAINT `orden_solicitud_ibfk_2` FOREIGN KEY (`estado_id`) REFERENCES `estado` (`id`),
  ADD CONSTRAINT `orden_solicitud_ibfk_3` FOREIGN KEY (`persona_id`) REFERENCES `persona` (`id`),
  ADD CONSTRAINT `orden_solicitud_ibfk_4` FOREIGN KEY (`tipo_id`) REFERENCES `tipo_orden` (`id`),
  ADD CONSTRAINT `orden_solicitud_ibfk_5` FOREIGN KEY (`departamento_id`) REFERENCES `departamento` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `orden_trabajo`
--
ALTER TABLE `orden_trabajo`
  ADD CONSTRAINT `orden_trabajo_ibfk_1` FOREIGN KEY (`orden_id`) REFERENCES `orden_solicitud` (`id`),
  ADD CONSTRAINT `orden_trabajo_ibfk_2` FOREIGN KEY (`persona_id`) REFERENCES `persona` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `permisos`
--
ALTER TABLE `permisos`
  ADD CONSTRAINT `permisos_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`),
  ADD CONSTRAINT `permisos_ibfk_2` FOREIGN KEY (`modulo_id`) REFERENCES `modulo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `persona_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`),
  ADD CONSTRAINT `persona_ibfk_2` FOREIGN KEY (`departamento_id`) REFERENCES `departamento` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
